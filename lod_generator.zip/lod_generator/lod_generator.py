bl_info = {
    "name": "LOD Generator",
    "blender": (3, 0, 0),
    "category": "Object",
    "version": (1, 0),
    "author": "Your Name",
    "description": "Generates LOD levels for objects in a collection, with customizable settings.",
}

import bpy
import os
from PIL import Image, ImageFilter

# Default LOD settings
DEFAULT_LOD_SETTINGS = [
    {"name": "8K", "resolution": 8192, "decimate_ratio": 1.0},
    {"name": "4K", "resolution": 4096, "decimate_ratio": 1.0},
    {"name": "1K", "resolution": 1024, "decimate_ratio": 0.75},
    {"name": "512", "resolution": 512, "decimate_ratio": 0.25},
    {"name": "64", "resolution": 64, "decimate_ratio": 0.05},
]

# Property group to store LOD settings
class LODSettings(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Name", default="LOD")
    resolution: bpy.props.IntProperty(name="Resolution", min=1, default=1024)
    decimate_ratio: bpy.props.FloatProperty(name="Decimate Ratio", min=0.01, max=1.0, default=1.0)

# Utility function to unpack and read texture resolution
def get_texture_resolution(image, obj_name, material_name):
    """Unpacks the image (if packed) and returns its resolution."""
    if image.packed_file:
        temp_path = bpy.path.abspath(f"//{obj_name}_{material_name}_{image.name}.png")
        image.filepath = temp_path
        image.unpack(method='USE_LOCAL')
        img_path = temp_path
    else:
        img_path = bpy.path.abspath(image.filepath)

    try:
        with Image.open(img_path) as img:
            width, height = img.size
            return (width, height)
    except Exception as e:
        print(f"Failed to read texture resolution: {e}")
        return (0, 0)

# Utility function to find the closest LOD level
def find_closest_lod_level(resolution, lod_settings):
    """Finds the closest LOD level for the given resolution."""
    closest_level = None
    closest_diff = float('inf')

    for level in lod_settings:
        diff = abs(resolution - level.resolution)
        if diff < closest_diff:
            closest_diff = diff
            closest_level = level

    return closest_level

# Utility function to resize a texture
def resize_texture(image, target_resolution):
    """Resizes a texture to the target resolution using PIL."""
    if not image.filepath or not os.path.exists(bpy.path.abspath(image.filepath)):
        temp_path = bpy.path.abspath(f"//{image.name}.png")
        image.filepath = temp_path
        image.save()
        img_path = temp_path
    else:
        img_path = bpy.path.abspath(image.filepath)

    try:
        with Image.open(img_path) as img:
            img = img.resize((target_resolution, target_resolution), Image.Resampling.LANCZOS)
            img.save(img_path)
            image.reload()
            print(f"Resized texture: {image.name} to {target_resolution}x{target_resolution}")
    except Exception as e:
        print(f"Failed to resize texture: {e}")

# Utility function to add a decimation modifier (but not apply it)
def add_decimation_modifier(obj, decimate_ratio):
    """Adds a decimation modifier to the object without applying it."""
    if decimate_ratio < 1.0:
        for modifier in obj.modifiers:
            if modifier.type == 'DECIMATE':
                obj.modifiers.remove(modifier)
        modifier = obj.modifiers.new(name="Decimate", type='DECIMATE')
        modifier.ratio = decimate_ratio

# Utility function to export a collection as a .glb or .fbx file
def export_collection(collection, output_path, export_format):
    """Exports the collection as a .glb or .fbx file, applying modifiers."""
    bpy.ops.object.select_all(action='DESELECT')
    for obj in collection.objects:
        obj.select_set(True)

    if export_format == 'GLB':
        bpy.ops.export_scene.gltf(
            filepath=output_path,
            use_selection=True,
            export_format='GLB',
            export_apply=True,
        )
    elif export_format == 'FBX':
        bpy.ops.export_scene.fbx(
            filepath=output_path,
            use_selection=True,
            use_mesh_modifiers=True,
        )
    print(f"Exported collection to: {output_path}")

# Main operator to generate LODs
class OBJECT_OT_generate_lods(bpy.types.Operator):
    bl_idname = "object.generate_lods"
    bl_label = "Generate LODs"
    bl_description = "Generates LOD levels for objects in the selected collection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target_collection = context.scene.lod_target_collection
        lod_settings = context.scene.lod_settings
        output_folder = bpy.path.abspath(context.scene.lod_output_folder)
        export_format = context.scene.lod_export_format

        if not target_collection:
            self.report({'ERROR'}, "Target collection not set.")
            return {'CANCELLED'}

        if not output_folder:
            self.report({'ERROR'}, "Output folder not set.")
            return {'CANCELLED'}

        # Track the highest texture resolution
        max_resolution = 0

        # Iterate over all objects in the collection
        for obj in target_collection.objects:
            if obj.material_slots:
                for slot in obj.material_slots:
                    if slot.material and slot.material.use_nodes:
                        for node in slot.material.node_tree.nodes:
                            if node.type == 'TEX_IMAGE' and node.image:
                                width, height = get_texture_resolution(node.image, obj.name, slot.material.name)
                                current_resolution = max(width, height)
                                if current_resolution > max_resolution:
                                    max_resolution = current_resolution

        # Determine the closest LOD level
        if max_resolution > 0:
            closest_level = find_closest_lod_level(max_resolution, lod_settings)
            print(f"\nHighest texture resolution: {max_resolution}")
            print(f"Closest LOD level: {closest_level.name}")

            # Get the list of LOD levels below the closest level
            lod_levels = sorted(lod_settings, key=lambda x: x.resolution, reverse=True)
            start_index = lod_levels.index(closest_level)
            levels_to_generate = lod_levels[start_index:]

            # Export each LOD level
            os.makedirs(output_folder, exist_ok=True)

            for i, level in enumerate(levels_to_generate):
                lod_number = len(levels_to_generate) - 1 - i

                # Add decimation modifiers
                for obj in target_collection.objects:
                    add_decimation_modifier(obj, level.decimate_ratio)

                # Resize textures
                for obj in target_collection.objects:
                    for slot in obj.material_slots:
                        if slot.material and slot.material.use_nodes:
                            for node in slot.material.node_tree.nodes:
                                if node.type == 'TEX_IMAGE' and node.image:
                                    resize_texture(node.image, level.resolution)

                # Export the collection
                output_path = os.path.join(output_folder, f"LOD_{lod_number:02d}.{export_format.lower()}")
                export_collection(target_collection, output_path, export_format)

                # Remove decimation modifiers
                for obj in target_collection.objects:
                    for modifier in obj.modifiers:
                        if modifier.type == 'DECIMATE':
                            obj.modifiers.remove(modifier)
        else:
            self.report({'WARNING'}, "No textures found in the collection.")

        return {'FINISHED'}

# UI Panel for LOD settings
class VIEW3D_PT_lod_generator(bpy.types.Panel):
    bl_label = "LOD Generator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Target collection selector
        layout.prop_search(scene, "lod_target_collection", bpy.data, "collections", text="Target Collection")

        # Output folder selector
        layout.prop(scene, "lod_output_folder", text="Output Folder")

        # Export format selector
        layout.prop(scene, "lod_export_format", text="Export Format")

        # LOD settings list
        for i, lod_setting in enumerate(scene.lod_settings):
            box = layout.box()
            row = box.row()
            row.prop(lod_setting, "name", text="")
            row.prop(lod_setting, "resolution", text="Resolution")
            row.prop(lod_setting, "decimate_ratio", text="Decimate Ratio")
            row.operator("scene.remove_lod_setting", text="", icon='X').index = i

        # Add new LOD setting
        layout.operator("scene.add_lod_setting", text="Add LOD Level")

        # Generate LODs button
        layout.operator("object.generate_lods", text="Generate LODs")

# Operator to add a new LOD setting
class SCENE_OT_add_lod_setting(bpy.types.Operator):
    bl_idname = "scene.add_lod_setting"
    bl_label = "Add LOD Setting"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.lod_settings.add()
        return {'FINISHED'}

# Operator to remove a LOD setting
class SCENE_OT_remove_lod_setting(bpy.types.Operator):
    bl_idname = "scene.remove_lod_setting"
    bl_label = "Remove LOD Setting"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        context.scene.lod_settings.remove(self.index)
        return {'FINISHED'}

# Function to initialize default LOD settings
def initialize_default_lod_settings():
    """Adds default LOD settings to the scene."""
    scene = bpy.context.scene
    if not scene.lod_settings:
        for setting in DEFAULT_LOD_SETTINGS:
            new_setting = scene.lod_settings.add()
            new_setting.name = setting["name"]
            new_setting.resolution = setting["resolution"]
            new_setting.decimate_ratio = setting["decimate_ratio"]

# Timer to defer initialization
def deferred_initialization():
    """Runs after the addon is registered to initialize default settings."""
    initialize_default_lod_settings()
    return None  # Stop the timer

# Register and unregister functions
def register():
    bpy.utils.register_class(LODSettings)
    bpy.utils.register_class(OBJECT_OT_generate_lods)
    bpy.utils.register_class(VIEW3D_PT_lod_generator)
    bpy.utils.register_class(SCENE_OT_add_lod_setting)
    bpy.utils.register_class(SCENE_OT_remove_lod_setting)

    bpy.types.Scene.lod_target_collection = bpy.props.PointerProperty(type=bpy.types.Collection)
    bpy.types.Scene.lod_settings = bpy.props.CollectionProperty(type=LODSettings)
    bpy.types.Scene.lod_output_folder = bpy.props.StringProperty(
        name="Output Folder",
        subtype='DIR_PATH',
        description="Choose the folder to save the LOD exports",
    )
    bpy.types.Scene.lod_export_format = bpy.props.EnumProperty(
        name="Export Format",
        items=[
            ('GLB', 'GLB', 'Export as GLB (GLTF Binary)'),
            ('FBX', 'FBX', 'Export as FBX'),
        ],
        default='GLB',
    )

    # Defer initialization using a timer
    bpy.app.timers.register(deferred_initialization, first_interval=1.0)

def unregister():
    bpy.utils.unregister_class(LODSettings)
    bpy.utils.unregister_class(OBJECT_OT_generate_lods)
    bpy.utils.unregister_class(VIEW3D_PT_lod_generator)
    bpy.utils.unregister_class(SCENE_OT_add_lod_setting)
    bpy.utils.unregister_class(SCENE_OT_remove_lod_setting)

    del bpy.types.Scene.lod_target_collection
    del bpy.types.Scene.lod_settings
    del bpy.types.Scene.lod_output_folder
    del bpy.types.Scene.lod_export_format

if __name__ == "__main__":
    register()