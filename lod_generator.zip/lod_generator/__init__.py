bl_info = {
    "name": "LOD Generator",
    "blender": (3, 0, 0),
    "category": "Object",
    "version": (1, 0),
    "author": "github.com/CarlaCGDM",
    "description": "Generates LOD levels for objects in a collection, with customizable settings.",
}

# Import the main script
from . import lod_generator

def register():
    lod_generator.register()

def unregister():
    lod_generator.unregister()

if __name__ == "__main__":
    register()